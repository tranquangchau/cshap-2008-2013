using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace F1moinoi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tabPage1.Text = "1Who";
            tabPage2.Text = "2When";
            tabPage3.Text = "3Where";
            tabPage4.Text = "4What";
            tabPage5.Text = "5How";
            tabPage6.Text = "6Why";
            tabPage7.Text = "7Yes/No";
            tabPage8.Text = "8Choice";
            tabPage9.Text = "9Statements";
        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            label2.Text = "Da Chon";
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            label3.Text = "Da chon hehe";
        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }
    }
}